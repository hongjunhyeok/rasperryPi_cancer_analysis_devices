#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "QtSql/QSqlDatabase"
#include "QtSql/QSqlQuery"
#include "QtSql/QSqlError"
#include "QtDebug"
#include "QCoreApplication"
#include "QString"



//db
QString HostName ="localhost";
QString UserID = "pi";
QString UserPW = "raspberry";
QString DBname = "rpi4db";
QString username = "hong";
QString TableName="rpi";
QString select_query="select Name from "+TableName+ " where age>25";
QString insert_query="INSERT into `"+DBname+"`.`"+TableName+"`"
                                                            " (`Name`, `Major`, `Age`,`Sex`)"
                                                            "  VALUES (:name,:major,:age,:sex)";
//db



bool db_connect();
QString get_data_from_db();
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
qDebug() << "availables drivers: " << QSqlDatabase::drivers();
}

MainWindow::~MainWindow()
{
    delete ui;
}

bool db_connect(){
       QSqlDatabase db = QSqlDatabase::addDatabase("QMYSQL3");
       db.setPort(3306);

       //hosting
       db.setHostName(HostName);
       db.setUserName(UserID);
       db.setPassword(UserPW);//raspberry
       db.setDatabaseName(DBname);//db


       if(db.open()){
           qDebug()<<"Database connected";
           return true;
       }
    return false;
}

QString get_data_from_db(QString tmp_query){
    QSqlQuery query;


    if(!query.exec(tmp_query)){
        return query.lastError().text();
    }else{
        QString rst="";
        while(query.next()){
            rst+= query.value(0).toString();
            rst+='\n';
        }
        return rst;
    }

}

QString set_data_from_db(QString tmp_query){
    QSqlQuery query;

    query.prepare(tmp_query);
    query.bindValue(":name","Hyeok");
    query.bindValue(":major","CS");
    query.bindValue(":age","21");
    query.bindValue(":sex","female");

    if(!query.exec())
         return query.lastError().text();
     else{
         return "Database Insert success";
     }

}

void MainWindow::on_pushButton_clicked()
{
    if (db_connect()){

        QString rst=get_data_from_db(select_query);
        qDebug() << rst;
        ui->textEdit->setText(rst);

    }
    else{
        ui->textEdit->setText("connection failed");
    }
}

void MainWindow::on_pushButton_2_clicked()
{
    if(db_connect()){
        QString rst=set_data_from_db(insert_query);
        ui->textEdit->setText(rst);
    }
    else{
        ui->textEdit->setText("connection failed");
    }
}
